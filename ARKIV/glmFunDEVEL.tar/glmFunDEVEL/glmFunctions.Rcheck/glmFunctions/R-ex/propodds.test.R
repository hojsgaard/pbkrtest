### Name: propodds.test
### Title: Likelihood-Ratio-Test of proportional odds assumption
### Aliases: propodds.test
### Keywords: models regression

### ** Examples

library(dataRep)
data(cheeseTaste)
attach(cheeseTaste)
require(MASS)
taste<-ordered(taste)
cheese<-factor(cheese)
fit<-polr(taste~cheese,weights=count)
kk<-propodds.test(fit,data=data.frame(taste,cheese,count))
  


