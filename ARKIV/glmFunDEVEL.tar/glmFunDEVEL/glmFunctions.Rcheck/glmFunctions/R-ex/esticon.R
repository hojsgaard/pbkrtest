### Name: esticon
### Title: Contrasts for lm, glm, lme, and geese objects
### Aliases: esticon
### Keywords: utilities

### ** Examples

data(iris)
lm1  <- lm(Sepal.Length~Sepal.Width+Species+Sepal.Width:Species, data=iris)
glm1 <- glm(Sepal.Length~Sepal.Width+Species+Sepal.Width:Species, data=iris,family=quasipoisson("identity"))
lambda1 <- c(1,0,1,0,0,0)
lambda2 <- c(1,0,0,1,0,0)
esticon(lm1,rbind(lambda1,lambda2))
esticon(glm1,rbind(lambda1,lambda2))



