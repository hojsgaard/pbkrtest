### Name: smooth.line
### Title: adds smooth line to a plot
### Aliases: smooth.line
### Keywords: regression

### ** Examples

x<-1:9
y<-x+rnorm(x)
plot(x,y)
smooth.line(x,y,span=0.6,se=TRUE)



