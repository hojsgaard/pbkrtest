### Name: pred.profileCI
### Title: profile likelihood confidence intervals for predicted means
### Aliases: pred.profileCI confidence
### Keywords: regression

### ** Examples

require(dataRep)
data(budworm)
attach(budworm)
y<-cbind(ndead,ntotal-ndead)
logdose<-log(dose)
k<-glm(y~sex + logdose,family=binomial)
ci<-pred.profileCI(k,x.factor=list(sex='female'),x.numeric=list(logdose=2))



