### Name: dose.ld50
### Title: LD50 and 95% confidence intervals (Wald and Fieller)
### Aliases: dose.ld50 LD50
### Keywords: regression

### ** Examples

library(dataRep)
data(budworm)
attach(budworm)
trial<-ntotal
dead<-ndead
logDose<-log(dose)
y<-cbind(dead,trial-dead)
fit<-glm(y~sex+logDose,family=binomial(link=logit))
ld50<-dose.ld50(fit,'logDose',list(sex='male'))
detach(budworm)



