### Name: stand.res
### Title: standardized deviance residuals
### Aliases: stand.res
### Keywords: regression

### ** Examples

x<-seq(0,1,0.1)
logit.p<-0.2+0.4*x
p<-plogis(logit.p)
y<-rbinom(length(p),1,p)
g<-glm(y~x,family=binomial)
r<-stand.res(g)



