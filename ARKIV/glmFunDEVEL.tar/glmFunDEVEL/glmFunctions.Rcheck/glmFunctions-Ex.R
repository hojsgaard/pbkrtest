### * <HEADER>
###
attach(NULL, name = "CheckExEnv")
assign(".CheckExEnv", as.environment(2), pos = length(search())) # base
## This plot.new() patch has no effect yet for persp();
## layout() & filled.contour() are now ok
assign("plot.new",
       function() {
	   .Internal(plot.new())
	   pp <- par(c("mfg","mfcol","oma","mar"))
	   if(all(pp$mfg[1:2] == c(1, pp$mfcol[2]))) {
               outer <- (oma4 <- pp$oma[4]) > 0; mar4 <- pp$mar[4]
               mtext(paste("help(", ..nameEx, ")"), side = 4,
                     line = if(outer)max(1, oma4 - 1) else min(1, mar4 - 1),
                     outer = outer, adj = 1, cex = .8, col = "orchid")
	   }
       },
       env = environment(plot))
assign("cleanEx",
       function(env = .GlobalEnv) {
	   rm(list = ls(envir = env, all.names = TRUE), envir = env)
           RNGkind("Wichmann-Hill", "default")
	   assign(".Random.seed", c(0, rep(7654, 3)), pos = 1)
	   assign("T", delay(stop("T used instead of TRUE")),
		  pos = .CheckExEnv)
	   assign("F", delay(stop("F used instead of FALSE")),
		  pos = .CheckExEnv)
       },
       env = .CheckExEnv)
assign("..nameEx", "__{must remake R-ex/*.R}__", env = .CheckExEnv) # for now
assign("ptime", proc.time(), env = .CheckExEnv)
postscript("glmFunctions-Examples.ps")
assign("par.postscript", par(no.readonly = TRUE), env = .CheckExEnv)
options(contrasts = c(unordered = "contr.treatment", ordered = "contr.poly"), pager="console")
library('glmFunctions')

cleanEx(); ..nameEx <- "dose.ld50"

### * dose.ld50

### Name: dose.ld50
### Title: LD50 and 95% confidence intervals (Wald and Fieller)
### Aliases: dose.ld50 LD50
### Keywords: regression

### ** Examples

library(dataRep)
data(budworm)
attach(budworm)
trial<-ntotal
dead<-ndead
logDose<-log(dose)
y<-cbind(dead,trial-dead)
fit<-glm(y~sex+logDose,family=binomial(link=logit))
ld50<-dose.ld50(fit,'logDose',list(sex='male'))
detach(budworm)



cleanEx(); ..nameEx <- "esticon"

### * esticon

### Name: esticon
### Title: Contrasts for lm, glm, lme, and geese objects
### Aliases: esticon
### Keywords: utilities

### ** Examples

data(iris)
lm1  <- lm(Sepal.Length~Sepal.Width+Species+Sepal.Width:Species, data=iris)
glm1 <- glm(Sepal.Length~Sepal.Width+Species+Sepal.Width:Species, data=iris,family=quasipoisson("identity"))
lambda1 <- c(1,0,1,0,0,0)
lambda2 <- c(1,0,0,1,0,0)
esticon(lm1,rbind(lambda1,lambda2))
esticon(glm1,rbind(lambda1,lambda2))



cleanEx(); ..nameEx <- "pred.profileCI"

### * pred.profileCI

### Name: pred.profileCI
### Title: profile likelihood confidence intervals for predicted means
### Aliases: pred.profileCI confidence
### Keywords: regression

### ** Examples

require(dataRep)
data(budworm)
attach(budworm)
y<-cbind(ndead,ntotal-ndead)
logdose<-log(dose)
k<-glm(y~sex + logdose,family=binomial)
ci<-pred.profileCI(k,x.factor=list(sex='female'),x.numeric=list(logdose=2))



cleanEx(); ..nameEx <- "propodds.test"

### * propodds.test

### Name: propodds.test
### Title: Likelihood-Ratio-Test of proportional odds assumption
### Aliases: propodds.test
### Keywords: models regression

### ** Examples

library(dataRep)
data(cheeseTaste)
attach(cheeseTaste)
require(MASS)
taste<-ordered(taste)
cheese<-factor(cheese)
fit<-polr(taste~cheese,weights=count)
kk<-propodds.test(fit,data=data.frame(taste,cheese,count))
  


cleanEx(); ..nameEx <- "smooth.line"

### * smooth.line

### Name: smooth.line
### Title: adds smooth line to a plot
### Aliases: smooth.line
### Keywords: regression

### ** Examples

x<-1:9
y<-x+rnorm(x)
plot(x,y)
smooth.line(x,y,span=0.6,se=TRUE)



cleanEx(); ..nameEx <- "stand.res"

### * stand.res

### Name: stand.res
### Title: standardized deviance residuals
### Aliases: stand.res
### Keywords: regression

### ** Examples

x<-seq(0,1,0.1)
logit.p<-0.2+0.4*x
p<-plogis(logit.p)
y<-rbinom(length(p),1,p)
g<-glm(y~x,family=binomial)
r<-stand.res(g)



### * <FOOTER>
###
cat("Time elapsed: ", proc.time() - get("ptime", env = .CheckExEnv),"\n")
dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
