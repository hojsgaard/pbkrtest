"propodds.test" <-
function(fit.prop,data) {
#description
# tests the proportional odds assumption
# against a multinomial model
# arguments
# input:
#  fit.prop: object from fitting proportional odds model with
#          polr function  of package MASS
#  data: optional data frame
# output:
#   fit.multinom: fit form a multinomial model
#   p.value: p-value of the hypotheses of a proportional odds model
#   df: difference of degress of freedom between the multinomial model
#       and the proportional odds model
#loading package nnetfrom pacjacke MASS for the function multnom
require(nnet)
#
#1. fit a multinomial model
    ca <- fit.prop$call
    form <- as.formula(ca$formula)
    fit.multinom <- multinom(substitute(form), data=data,
                             weights = get(as.character(ca$weights)))
# calculate 
#  -2 (L(proportional odds-model) -L (multinomial model))
# =  deviance(proportional odds)- deviance( deviance)
    D <- fit.prop$deviance - fit.multinom$deviance
    df <- fit.multinom$edf - fit.prop$edf 
# p-value of H0: proportional odds assumption holds
    p.value <- 1 - pchisq(D, df)
    return(list(fit.multinom = fit.multinom, p.value = p.value, 
        df = df))

}
