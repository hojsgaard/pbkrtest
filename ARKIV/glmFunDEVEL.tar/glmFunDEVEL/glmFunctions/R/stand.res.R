"stand.res"<- 
function(object){
#standardized deviance residuals
r<-residuals(object)/sqrt (summary(object)$dispersion *
                             (1-hatvalues(object))  )
r
}

