"smooth.line"<-
function(x,y,span=0.8,degree=2,col=4,lwd=1,se=FALSE,col.se=2){
ort<-order(x)
x<-x[ort]
y<-y[ort]
k<-loess(y~x,span=span,degree=degree)
xv<-seq(min(x),max(x),l=50)
z<-data.frame(xv)
names(z)<-'x'
z<-predict(k,newdata=z,se=se)
if (se==FALSE) fit<-z
else  fit<-z$fit
lines(xv,fit,col=col)

if (se==TRUE) {
sefit<-z$se.fit
u<-fit-1.96*sefit
o<-fit+1.96*sefit
lines(xv,u,col=col.se,lty=2)
lines(xv,o,col=col.se,lty=2)
}
return()
}



