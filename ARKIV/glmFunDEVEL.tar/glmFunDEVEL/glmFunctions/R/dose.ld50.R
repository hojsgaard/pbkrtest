
dose.ld50<-function(obj,dosenam,x.factor=NULL,x.numeric=NULL) {

dat<-obj$model

#redefing the regressor variables, such
#they the new variables are zero where the
#original have the values at which the ld50 is required


if (!is.null(x.factor)) {
nams<-names(x.factor)
for (i in 1:length(x.factor)) {
dat[,nams[i]]<-relevel(dat[,nams[i]],x.factor[[nams[i]]])
}}


if (!is.null(x.numeric)) {
nams<-names(x.numeric)
for (i in 1:length(x.numeric)) {
dat[,nams[i]]<-dat[,nams[i]]-x.numeric[[nams[i]]]
}}




fo<-as.character(formula(obj))
fo<- as.formula(paste(fo[2],'~',fo[3],'+1'))

hh<-glm(fo,family=binomial,data=dat)

S<-summary(hh)$cov.unscaled

alpha<-coef(hh)['(Intercept)']
gamma<-coef(hh)[dosenam]

mu<--alpha/gamma


S11<-S['(Intercept)','(Intercept)']
S12<-S['(Intercept)',dosenam] 
S22<-S[dosenam,dosenam]

z<-qnorm(0.975)


s<-sqrt( (S11+2*mu*S12+mu^2*S22)/gamma^2)
ld50.delta<-data.frame(mu,'  ',mu-z*s,mu+z*s,s)
names(ld50.delta)<-c('ld50','where','2.5%','97.5%','se')


#calculating the Fieller interval
K<-z^2*S22/gamma^2
RR<-S11+2*mu*S12+mu^2*S22-K*(S11-S12^2/S22)

if (RR>0) {
  m<-z/(gamma*(1-K)) *sqrt(RR)
  e<-mu+ K/(1-K) * (mu+S12/S22)
   low<-e-m
   upp<-e+m
if (K<1) {ld50.fieller<-data.frame(mu,'in',low,upp)}
 else   {ld50.fieller<-data.frame(mu,'outside',low,upp)}
}
else
{ 
   ld50.fieller<-data.frame(mu,'in','-infinity','+infinity')
}
   ld50.fieller<-cbind(ld50.fieller,NA)
   names(ld50.fieller)<-c('ld50','where','2.5%','97.5%','se')
ld50<-rbind(ld50.delta,ld50.fieller)
rownames(ld50)<-c('delta-method',"Fieller's method")
return(ld50)
}


