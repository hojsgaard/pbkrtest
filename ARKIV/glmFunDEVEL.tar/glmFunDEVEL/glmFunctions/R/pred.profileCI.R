"pred.profileCI"<-
function (obj, x.factor = NULL, x.numeric = NULL) 
{
    require(MASS)
    dat <- obj$model
    if (!is.null(x.factor)) {
        nams <- names(x.factor)
        for (i in 1:length(x.factor)) {
            dat[, nams[i]] <- relevel(dat[, nams[i]], x.factor[[nams[i]]])
        }
    }
    if (!is.null(x.numeric)) {
        nams <- names(x.numeric)
        for (i in 1:length(x.numeric)) {
            dat[, nams[i]] <- dat[, nams[i]] - x.numeric[[nams[i]]]
        }
    }
    fo <- as.character(formula(obj))
    fo.SCHROTT <<- as.formula(paste(fo[2], "~", fo[3], "+1"))
    obj.SCHROTT<<-obj
    dat.SCHROTT<<-dat
    g<-glm(fo.SCHROTT,data=dat.SCHROTT,family=family(obj.SCHROTT))
    j.link<-confint(g)
    j.link<-c(g$coef['(Intercept)'],j.link['(Intercept)',])
    names(j.link)[1]<-'Estimate'
    j.response<-switch(family(g)[[2]],logit=plogis(j.link),log=exp(j.link),
                                         identity=j.link)
    return(list(ci.link=j.link,ci.response=j.response))
}





