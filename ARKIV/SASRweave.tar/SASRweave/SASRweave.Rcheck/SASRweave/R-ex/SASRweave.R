### Name: SASRweave
### Title: Literate programming with SAS and SAS+R
### Aliases: SASRweave
### Keywords: utilities

### ** Examples


## Not run: 
##D sasexec <- '"C:/Program Files/SAS/SAS 9.1/sas.exe"'
##D 
##D test1 <- system.file("SASweaveSRC", "test.Rnw", package = "SASRweave")
##D SASRweave(test1, sasexec)
##D SASRweave(test1, sasexec,latex=TRUE)
## End(Not run)



